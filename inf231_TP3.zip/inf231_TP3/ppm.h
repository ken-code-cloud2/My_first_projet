#ifndef PPM_H
#define PPM_H

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    unsigned char r,g,b;
} Pixel;

typedef struct {
    int width;
    int height;
    int maxval;
    Pixel *data; 
} Image;

Image *load_ppm(const char *filename);
int save_ppm(const char *filename, const Image *img);

Image *create_image(int width, int height, int maxval);
void free_image(Image *img);

Pixel get_pixel(const Image *img, int row, int col);
void set_pixel(Image *img, int row, int col, Pixel p);
int clamp(int x, int lo, int hi);

#endif 
