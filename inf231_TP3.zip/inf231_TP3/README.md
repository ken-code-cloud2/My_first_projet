 INF231 TP3

  1) Description générale du projet

Le projet PPMViewer est une application console écrite en langage C permettant de manipuler des images au format PPM (Portable PixMap), version P3 (texte).

Ce format représente les images à l’aide de triplets de valeurs (R, G, B), chaque pixel étant défini par ses composantes rouge, verte et bleue.

L’objectif du projet est d’écrire un programme capable de :

* Lire un fichier image .ppm,

* Effectuer plusieurs traitements sur cette image (conversion en gris, négatif, découpe, etc.),

* Enregistrer le résultat dans un nouveau fichier .ppm,

* Et permettre à l’utilisateur d’interagir via une interface en ligne de commande :


  2)  Structure du projet

  * main.c : Contient la boucle principale ppmviewer>, l’analyse des commandes saisies et l’appel des fonctions correspondantes.

 * ppm.h : Définit les structures Pixel et Image, ainsi que les prototypes de fonctions communes.

 * ppm.c : Gère la lecture et l’écriture des fichiers .ppm (version P3).

 * operations.c : Implémente les différentes opérations de traitement d’images.

 * Makefile : Permet de compiler facilement le projet.

 * exemple.ppm	Petite image d’exemple 4x4 utilisée pour les tests.


 3) Fonctionnalités principales

 * dom C val fichier.ppm : Fonce ou éclaircit les pixels dominants d’une couleur donnée (R, G ou B).

 * gris fichier.ppm : Convertit une image en niveaux de gris.

 * neg fichier.ppm fichier_resultat.ppm :	Produit le négatif d’une image.

 * size fichier.ppm : Affiche la taille de l’image en pixels.

 * cut fichier.ppm l1 l2 c1 c2 fichier_resultat.ppm :	Découpe une partie de l’image entre les lignes l1-l2 et colonnes c1-c2.

 * fil fichier.ppm fichier_resultat.ppm: Applique un filtre médian pour réduire le bruit.

 * quit : Quitte l’application.


 4) Organisation du travail entre les différents membres

  * Kenne Fabrel: s'est occupé du Développement du module ppm.c (lecture/écriture du format P3) et gestion de la mémoire (création/libération d’image).

  * Hachimi Isaac: s'est occupé de l'Implémentation des opérations dom, gris, neg et vérification de la validité des valeurs de pixels (clampage).

  * Manwai Irina: s'est occupée de la Conception et l'implémentation du filtre médian et de l’opération cut (découpage).

  * Matchongo Asnel: s'est occupé de la Conception du Makefile, création du main.c (boucle ppmviewer>), intégration de tous les modules et rédaction du README.

  5)  Consignes d’exécution

    a. Compilation :

      make

b. Exécution :

./ppmviewer


c. Exemple d’utilisation :

ppmviewer> size example.ppm
ppmviewer> gris example.ppm
ppmviewer> neg example.ppm result.ppm
ppmviewer> dom R 10 example.ppm
ppmviewer> cut example.ppm 1 2 1 3 image_part.ppm
ppmviewer> fil example.ppm image_fil.ppm
ppmviewer> quit


d. Nettoyage (optionnel) :

make clean


 6) prendre en compte avant l'exécution du programme
   
 * Le programme ne fonctionne que sur des fichiers PPM version P3 (texte).

 * Les fichiers doivent se trouver dans le même dossier que l’exécutable.

 * Le programme vérifie automatiquement les bornes lors de la découpe (cut).

 * Si un fichier n’est pas trouvé, un message clair est affiché :
   ''fichier non trouvé''.

 * Les résultats des opérations sont enregistrés sous un nouveau nom explicite (ex. nomimage_gris.ppm).