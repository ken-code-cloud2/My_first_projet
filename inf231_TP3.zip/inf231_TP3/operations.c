#include "ppm.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static Image *clone_image(const Image *src) {
    if (!src) return NULL;
    Image *dst = create_image(src->width, src->height, src->maxval);
    if (!dst) return NULL;
    memcpy(dst->data, src->data, sizeof(Pixel) * src->width * src->height);
    return dst;
}

int op_dom(const char color, int val, const char *filename) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    for (int r = 0; r < img->height; ++r) {
        for (int c = 0; c < img->width; ++c) {
            Pixel p = get_pixel(img, r, c);
            int dr = p.r, dg = p.g, db = p.b;
            char dom = 'R';
            if (dg > dr && dg >= db) dom = 'G';
            else if (db > dr && db > dg) dom = 'B';
            int match = 0;
            if ((color=='R' || color=='r') && dom=='R') match = 1;
            if ((color=='G' || color=='g') && dom=='G') match = 1;
            if ((color=='B' || color=='b') && dom=='B') match = 1;
            if (match) {
                int nr = clamp((int)p.r + val, 0, img->maxval);
                int ng = clamp((int)p.g + val, 0, img->maxval);
                int nb = clamp((int)p.b + val, 0, img->maxval);
                Pixel np = {(unsigned char)nr, (unsigned char)ng, (unsigned char)nb};
                set_pixel(img, r, c, np);
            }
        }
    }
    char out[1024];
    snprintf(out, sizeof(out), "%s_dom.ppm", filename);
    save_ppm(out, img);
    printf("opération effectuée ; %s créé\n", out);
    free_image(img);
    return 1;
}

int op_gris(const char *filename) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    for (int i = 0; i < img->width * img->height; ++i) {
        int avg = ((int)img->data[i].r + img->data[i].g + img->data[i].b) / 3;
        unsigned char v = (unsigned char) avg;
        img->data[i].r = img->data[i].g = img->data[i].b = v;
    }
    char out[1024];
    snprintf(out, sizeof(out), "%s_gris.ppm", filename);
    save_ppm(out, img);
    printf("opération effectuée ; %s créé\n", out);
    free_image(img);
    return 1;
}

int op_neg(const char *filename, const char *outname) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    for (int i = 0; i < img->width * img->height; ++i) {
        img->data[i].r = (unsigned char)(img->maxval - img->data[i].r);
        img->data[i].g = (unsigned char)(img->maxval - img->data[i].g);
        img->data[i].b = (unsigned char)(img->maxval - img->data[i].b);
    }
    save_ppm(outname, img);
    printf("opération effectuée\n");
    free_image(img);
    return 1;
}

int op_size(const char *filename) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    printf("%d x %d\n", img->width, img->height);
    free_image(img);
    return 1;
}

int op_cut(const char *filename, int l1, int l2, int c1, int c2, const char *outname) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    if (!(l1 < l2 && l2 <= img->height && c1 < c2 && c2 <= img->width)) {
        printf("coordonnées invalides\n");
        free_image(img);
        return 0;
    }
    int new_h = l2 - l1 + 1;
    int new_w = c2 - c1 + 1;
    Image *out = create_image(new_w, new_h, img->maxval);
    for (int i = 0; i < new_h; ++i) {
        for (int j = 0; j < new_w; ++j) {
            Pixel p = get_pixel(img, (l1 - 1) + i, (c1 - 1) + j);
            set_pixel(out, i, j, p);
        }
    }
    save_ppm(outname, out);
    printf("opération effectuée\n");
    free_image(img);
    free_image(out);
    return 1;
}

static int cmp_int(const void *a, const void *b) {
    int ia = *(const int*)a;
    int ib = *(const int*)b;
    return (ia > ib) - (ia < ib);
}

int op_fil(const char *filename, const char *outname) {
    Image *img = load_ppm(filename);
    if (!img) { printf("fichier non trouvé\n"); return 0; }
    Image *out = clone_image(img);
    int w = img->width, h = img->height;
    int valsR[9], valsG[9], valsB[9];
    for (int r = 0; r < h; ++r) {
        for (int c = 0; c < w; ++c) {
            int k = 0;
            for (int dr = -1; dr <= 1; ++dr) {
                for (int dc = -1; dc <= 1; ++dc) {
                    int rr = r + dr, cc = c + dc;
                    if (rr < 0 || rr >= h || cc < 0 || cc >= w) continue;
                    Pixel p = get_pixel(img, rr, cc);
                    valsR[k] = p.r; valsG[k] = p.g; valsB[k] = p.b;
                    k++;
                }
            }
            
            qsort(valsR, k, sizeof(int), cmp_int);
            qsort(valsG, k, sizeof(int), cmp_int);
            qsort(valsB, k, sizeof(int), cmp_int);
            int median_index = k/2;
            Pixel np;
            np.r = (unsigned char)valsR[median_index];
            np.g = (unsigned char)valsG[median_index];
            np.b = (unsigned char)valsB[median_index];
            set_pixel(out, r, c, np);
        }
    }
    save_ppm(outname, out);
    printf("opération effectuée\n");
    free_image(img);
    free_image(out);
    return 1;
}
