#include "ppm.h"
#include <string.h>
#include <ctype.h>

static int read_next_int(FILE *f, int *out) {
    int c;
   
    while ((c = fgetc(f)) != EOF) {
        if (isspace(c)) continue;
        if (c == '#') {
           
            while ((c = fgetc(f)) != EOF && c!='\n');
            continue;
        }
        ungetc(c, f);
        break;
    }
    if (c == EOF) return 0;
    if (fscanf(f, "%d", out) != 1) return 0;
    return 1;
}

Image *create_image(int width, int height, int maxval) {
    Image *img = malloc(sizeof(Image));
    if (!img) return NULL;
    img->width = width;
    img->height = height;
    img->maxval = maxval;
    img->data = malloc(sizeof(Pixel) * width * height);
    if (!img->data) { free(img); return NULL; }
    return img;
}

void free_image(Image *img) {
    if (!img) return;
    free(img->data);
    free(img);
}

Pixel get_pixel(const Image *img, int row, int col) {
    Pixel p = {0,0,0};
    if (!img) return p;
    if (row < 0 || row >= img->height || col < 0 || col >= img->width) return p;
    return img->data[row * img->width + col];
}

void set_pixel(Image *img, int row, int col, Pixel p) {
    if (!img) return;
    if (row < 0 || row >= img->height || col < 0 || col >= img->width) return;
    img->data[row * img->width + col] = p;
}

int clamp(int x, int lo, int hi) {
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

Image *load_ppm(const char *filename) {
    FILE *f = fopen(filename, "r");
    if (!f) return NULL;
    char magic[3] = {0};
    if (fscanf(f, "%2s", magic) != 1) { fclose(f); return NULL; }
    if (strcmp(magic, "P3") != 0) { fclose(f); return NULL; } 

    int width, height, maxval;
    if (!read_next_int(f, &width)) { fclose(f); return NULL; }
    if (!read_next_int(f, &height)) { fclose(f); return NULL; }
    if (!read_next_int(f, &maxval)) { fclose(f); return NULL; }

    Image *img = create_image(width, height, maxval);
    if (!img) { fclose(f); return NULL; }

    for (int i = 0; i < width * height; ++i) {
        int r,g,b;
        if (!read_next_int(f, &r) || !read_next_int(f, &g) || !read_next_int(f, &b)) {
            free_image(img); fclose(f); return NULL;
        }
        img->data[i].r = (unsigned char) clamp(r, 0, img->maxval);
        img->data[i].g = (unsigned char) clamp(g, 0, img->maxval);
        img->data[i].b = (unsigned char) clamp(b, 0, img->maxval);
    }

    fclose(f);
    return img;
}

int save_ppm(const char *filename, const Image *img) {
    if (!img) return 0;
    FILE *f = fopen(filename, "w");
    if (!f) return 0;
    fprintf(f, "P3\n");
    fprintf(f, "%d %d\n", img->width, img->height);
    fprintf(f, "%d\n", img->maxval);
    int cnt = 0;
    for (int i = 0; i < img->width * img->height; ++i) {
        fprintf(f, "%d %d %d ", img->data[i].r, img->data[i].g, img->data[i].b);
        cnt++;
        if (cnt % 5 == 0) fprintf(f, "\n");
    }
    if (cnt % 5 != 0) fprintf(f, "\n");
    fclose(f);
    return 1;
}
