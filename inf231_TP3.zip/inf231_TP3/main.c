#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ppm.h"

int op_dom(const char color, int val, const char *filename);
int op_gris(const char *filename);
int op_neg(const char *filename, const char *outname);
int op_size(const char *filename);
int op_cut(const char *filename, int l1, int l2, int c1, int c2, const char *outname);
int op_fil(const char *filename, const char *outname);

int main(void) {
    char line[1024];
    printf("Application de traitement d'images PPM réalisée par Kenne Fabrel; Hachimi Isaac; Manwai Irina; Matchongo Asnel.\n");
    while (1) {
        printf("ppmviewer> ");
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strlen(line) == 0) continue;
        char *args[10];
        int argc = 0;
        char *tok = strtok(line, " \t");
        while (tok && argc < 10) { args[argc++] = tok; tok = strtok(NULL, " \t"); }

        if (argc == 0) continue;
        if (strcmp(args[0], "quit") == 0) break;
        else if (strcmp(args[0], "dom") == 0) {
            if (argc != 4) { printf("Usage: dom C val fichier.ppm\n"); continue; }
            char col = args[1][0];
            int val = atoi(args[2]);
            op_dom(col, val, args[3]);
        } else if (strcmp(args[0], "gris") == 0) {
            if (argc != 2) { printf("Usage: gris fichier.ppm\n"); continue; }
            op_gris(args[1]);
        } else if (strcmp(args[0], "neg") == 0) {
            if (argc != 3) { printf("Usage: neg fichier.ppm fichier_resultat.ppm\n"); continue; }
            op_neg(args[1], args[2]);
        } else if (strcmp(args[0], "size") == 0) {
            if (argc != 2) { printf("Usage: size fichier.ppm\n"); continue; }
            op_size(args[1]);
        } else if (strcmp(args[0], "cut") == 0) {
            if (argc != 7) { printf("Usage: cut fichier.ppm l1 l2 c1 c2 fichier_resultat.ppm\n"); continue; }
            int l1 = atoi(args[2]), l2 = atoi(args[3]), c1 = atoi(args[4]), c2 = atoi(args[5]);
            op_cut(args[1], l1, l2, c1, c2, args[6]);
        } else if (strcmp(args[0], "fil") == 0) {
            if (argc != 3) { printf("Usage: fil fichier.ppm fichier_resultat.ppm\n"); continue; }
            op_fil(args[1], args[2]);
        } else {
            printf("commande inconnue\n");
        }
    }
    printf("bye\n");
    return 0;
}
